![](http://3dsnode.github.io/img/logo.png)

# Installation :
####Download last stable build
1. Download the last build [here](http://3dsnode.github.io/downloads/3dsNode-stable.zip)
2. Unzip
3. `npm start` or `node index.js`

####Creating package by yourself
1. Download the last build sources
2. `npm install`
3. `npm start` or `node index.js`
